import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.LinkedList;
import java.util.Random;
import javax.imageio.ImageIO;

public class SnakeGame extends JPanel implements ActionListener {
    private final int WIDTH = 1800;
    private final int HEIGHT = 900;
    private final int BOX_SIZE = 50;
    private final int NUM_BOXES_X = WIDTH / BOX_SIZE;
    private final int NUM_BOXES_Y = HEIGHT / BOX_SIZE;

    private LinkedList<Point> snake1;
    private LinkedList<Point> snake2;
    private Point food;
    private Point speedUpItem;
    private char direction1;
    private char direction2;
    private boolean gameOver;
    private boolean isSinglePlayer;
    private boolean snake1Speeding;
    private boolean snake2Speeding;
    private int speedUpDuration;
    private Timer timer;
    private int normalDelay = 100;
    private int fastDelay = 50;

    private BufferedImage snake1Image;
    private BufferedImage snake2Image;
    private BufferedImage foodImage;
    private BufferedImage speedUpItemImage;
    private BufferedImage backgroundImage;

    public SnakeGame() {
        setPreferredSize(new Dimension(WIDTH, HEIGHT));
        isSinglePlayer = chooseGameMode();
        initializeGame();
        loadImages();

        timer = new Timer(normalDelay, this);
        timer.start();

        addKeyListener(new KeyAdapter() {
            public void keyPressed(KeyEvent e) {
                handleKeyPress(e);
            }
        });
        setFocusable(true);
    }

    private boolean chooseGameMode() {
        Object[] options = {"单人模式", "双人模式"};
        int choice = JOptionPane.showOptionDialog(this,
                "请选择游戏模式",
                "游戏模式选择",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE,
                null,
                options,
                options[0]);
        return choice == 0;
    }

    private void initializeGame() {
        snake1 = new LinkedList<>();
        snake1.add(new Point(NUM_BOXES_X / 2, NUM_BOXES_Y / 2));
        direction1 = 'R';

        if (!isSinglePlayer) {
            snake2 = new LinkedList<>();
            snake2.add(new Point(NUM_BOXES_X / 2 - 5, NUM_BOXES_Y / 2));
            direction2 = 'R';
        }

        spawnFood();
        spawnSpeedUpItem();
        gameOver = false;
        snake1Speeding = false;
        snake2Speeding = false;
        speedUpDuration = 0;
    }

    private void loadImages() {
        try {
            snake1Image = ImageIO.read(getClass().getResource("/imagine/snake1.png"));
            snake2Image = ImageIO.read(getClass().getResource("/imagine/snake2.png"));
            foodImage = ImageIO.read(getClass().getResource("/imagine/food.png"));
            speedUpItemImage = ImageIO.read(getClass().getResource("/imagine/speedup.png"));
            backgroundImage = ImageIO.read(getClass().getResource("/imagine/background.png"));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void spawnFood() {
        Random random = new Random();
        food = new Point(random.nextInt(NUM_BOXES_X), random.nextInt(NUM_BOXES_Y));
    }

    private void spawnSpeedUpItem() {
        Random random = new Random();
        speedUpItem = new Point(random.nextInt(NUM_BOXES_X), random.nextInt(NUM_BOXES_Y));
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (!gameOver) {
            if (snake1Speeding || snake2Speeding) {
                speedUpDuration--;
                if (speedUpDuration <= 0) {
                    snake1Speeding = false;
                    snake2Speeding = false;
                    timer.setDelay(normalDelay);
                }
            }
            moveSnakes();
            checkCollisions();
            checkItemCollision();
            repaint();
        }
    }

    private void moveSnakes() {
        moveSnake(snake1, direction1);
        if (!isSinglePlayer) {
            moveSnake(snake2, direction2);
        }
    }

    private void moveSnake(LinkedList<Point> snake, char direction) {
        Point head = snake.getFirst();
        Point newHead = new Point(head);

        switch (direction) {
            case 'U':
                newHead.translate(0, -1);
                break;
            case 'D':
                newHead.translate(0, 1);
                break;
            case 'L':
                newHead.translate(-1, 0);
                break;
            case 'R':
                newHead.translate(1, 0);
                break;
        }

        if (newHead.equals(food)) {
            snake.addFirst(newHead);
            spawnFood();
        } else {
            snake.addFirst(newHead);
            snake.removeLast();
        }
    }

    private void checkCollisions() {
        Point head1 = snake1.getFirst();
        boolean snake1Collided = head1.x < 0 || head1.x >= NUM_BOXES_X || head1.y < 0 || head1.y >= NUM_BOXES_Y || snake1.subList(1, snake1.size()).contains(head1);
        boolean snake2Collided = false;

        if (!isSinglePlayer) {
            Point head2 = snake2.getFirst();
            snake2Collided = head2.x < 0 || head2.x >= NUM_BOXES_X || head2.y < 0 || head2.y >= NUM_BOXES_Y || snake2.subList(1, snake2.size()).contains(head2);

            // 检测蛇头碰撞
            if (head1.equals(head2)) {
                snake1Collided = true;
                snake2Collided = true;
            } else {
                snake1Collided = snake1Collided || snake2.contains(head1);
                snake2Collided = snake2Collided || snake1.contains(head2);
            }
        }

        if (snake1Collided || snake2Collided) {
            gameOver = true;
        }
    }

    private void checkItemCollision() {
        Point head1 = snake1.getFirst();
        if (head1.equals(speedUpItem)) {
            snake1Speeding = true;
            speedUpDuration = 20;
            timer.setDelay(fastDelay);
            spawnSpeedUpItem();
        }

        if (!isSinglePlayer) {
            Point head2 = snake2.getFirst();
            if (head2.equals(speedUpItem)) {
                snake2Speeding = true;
                speedUpDuration = 20;
                timer.setDelay(fastDelay);
                spawnSpeedUpItem();
            }
        }
    }

    private void handleKeyPress(KeyEvent e) {
        switch (e.getKeyCode()) {
            case KeyEvent.VK_UP:
                if (direction1 != 'D') direction1 = 'U';
                break;
            case KeyEvent.VK_DOWN:
                if (direction1 != 'U') direction1 = 'D';
                break;
            case KeyEvent.VK_LEFT:
                if (direction1 != 'R') direction1 = 'L';
                break;
            case KeyEvent.VK_RIGHT:
                if (direction1 != 'L') direction1 = 'R';
                break;
            case KeyEvent.VK_W:
                if (!isSinglePlayer && direction2 != 'D') direction2 = 'U';
                break;
            case KeyEvent.VK_S:
                if (!isSinglePlayer && direction2 != 'U') direction2 = 'D';
                break;
            case KeyEvent.VK_A:
                if (!isSinglePlayer && direction2 != 'R') direction2 = 'L';
                break;
            case KeyEvent.VK_D:
                if (!isSinglePlayer && direction2 != 'L') direction2 = 'R';
                break;
        }
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        if (backgroundImage != null) {
            g.drawImage(backgroundImage, 0, 0, WIDTH, HEIGHT, this);
        } else {
            g.setColor(Color.LIGHT_GRAY);
            g.fillRect(0, 0, WIDTH, HEIGHT);
        }

        if (snake1Image != null) {
            for (Point p : snake1) {
                g.drawImage(snake1Image, p.x * BOX_SIZE, p.y * BOX_SIZE, BOX_SIZE, BOX_SIZE, this);
            }
        } else {
            g.setColor(Color.GREEN);
            for (Point p : snake1) {
                g.fillRect(p.x * BOX_SIZE, p.y * BOX_SIZE, BOX_SIZE, BOX_SIZE);
            }
        }

        if (!isSinglePlayer) {
            if (snake2Image != null) {
                for (Point p : snake2) {
                    g.drawImage(snake2Image, p.x * BOX_SIZE, p.y * BOX_SIZE, BOX_SIZE, BOX_SIZE, this);
                }
            } else {
                g.setColor(Color.BLUE);
                for (Point p : snake2) {
                    g.fillRect(p.x * BOX_SIZE, p.y * BOX_SIZE, BOX_SIZE, BOX_SIZE);
                }
            }
        }

        if (foodImage != null) {
            g.drawImage(foodImage, food.x * BOX_SIZE, food.y * BOX_SIZE, BOX_SIZE, BOX_SIZE, this);
        } else {
            g.setColor(Color.RED);
            g.fillRect(food.x * BOX_SIZE, food.y * BOX_SIZE, BOX_SIZE, BOX_SIZE);
        }

        if (speedUpItemImage != null) {
            g.drawImage(speedUpItemImage, speedUpItem.x * BOX_SIZE, speedUpItem.y * BOX_SIZE, BOX_SIZE, BOX_SIZE, this);
        } else {
            g.setColor(Color.YELLOW);
            g.fillRect(speedUpItem.x * BOX_SIZE, speedUpItem.y * BOX_SIZE, BOX_SIZE, BOX_SIZE);
        }

        if (gameOver) {
            g.setColor(Color.BLACK);
            g.setFont(new Font("Arial", Font.BOLD, 36));
            g.drawString("Game Over", WIDTH / 2 - 100, HEIGHT / 2);
        }
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Snake Game");
        SnakeGame game = new SnakeGame();
        frame.add(game);
        frame.pack();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
}